package com.example.miaula.models

data class Student(val idCourse: Int, var surname: String, var name: String, var gender: String)