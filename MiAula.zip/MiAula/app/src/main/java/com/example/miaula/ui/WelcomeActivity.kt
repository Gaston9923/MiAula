package com.example.miaula.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.example.miaula.MainActivity
import com.example.miaula.R
import com.example.miaula.databinding.ActivityWelcomeBinding
import com.example.miaula.models.User
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class WelcomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWelcomeBinding
    private lateinit var navController: NavController

    private var btnSignGoogle: Button? = null
    private var googleSignInClient: GoogleSignInClient? = null
    private val firebaseAuth = FirebaseAuth.getInstance()
    private var userLogin: User? = null

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_welcome)
//        btnSignGoogle = findViewById(R.id.btn_sign_google)
//        createRequest()
////        btnSignGoogle.setOnClickListener(View.OnClickListener { signIn() })
//
////        if (authUser.getCurrentUser() != null){
////            Intent intent = new Intent(this,MainActivity.class);
////            startActivity(intent);
////            finish();
////        }else{
////
////        }
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainerView2) as NavHostFragment
        navController = navHostFragment.navController
        navController.addOnDestinationChangedListener(this)
    }


    private fun createRequest() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(com.firebase.ui.auth.R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
    }

    private fun signIn() {
        val signIntent = googleSignInClient!!.signInIntent
        startActivityForResult(signIntent, RC_SIGN_IN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        //Resultado devuelto al iniciar la intencion desde GoogleSignInApi.getSignIntent
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                //Inicio exitoso
                val account = task.getResult(ApiException::class.java)
                AutenticacionFirebase(account)
            } catch (e: ApiException) {
            }
        }
    }

    private fun AutenticacionFirebase(account: GoogleSignInAccount) {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(this) { task ->
            if (task.isSuccessful) {
                //Si inicio correctamente
                val user = firebaseAuth.currentUser

//                    if (task.getResult().getAdditionalUserInfo().isNewUser()){
                val uid = user!!.uid
                val correo = user.email
                val name = user.displayName
                val number = user.phoneNumber
                val photo = user.photoUrl
//                userLogin = User(uid, correo, name, number, photo)
                Toast.makeText(applicationContext, "Usuario:$uid$correo$name", Toast.LENGTH_LONG)
                    .show()
                //                    }
                //Ir al inicio de la app
                val mainActivityIntent = Intent(applicationContext, MainActivity::class.java)
                val bundle = Bundle()
//                bundle.putSerializable("userLogin", userLogin)
                //                    mainActivityIntent.putExtra("userLogin",userLogin);
                mainActivityIntent.putExtras(bundle)
                startActivity(mainActivityIntent)
            } else {
                Toast.makeText(
                    applicationContext,
                    "Hubo un error al iniciar sesión, intente nuevamente!",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    companion object {
        private const val RC_SIGN_IN = 123
    }
}